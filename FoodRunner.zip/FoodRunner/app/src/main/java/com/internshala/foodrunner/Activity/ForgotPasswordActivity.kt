package com.internshala.foodrunner.Activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.internshala.foodrunner.R

class ForgotPasswordActivity : AppCompatActivity() {
    lateinit var etForgotPasswordMobileNumber:EditText
    lateinit var etForgotPasswordEmail:EditText
    lateinit var btnNext:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)
        title="Forgot Password Page"
        etForgotPasswordMobileNumber=findViewById(R.id.etForgotPasswordMobileNumber)
        etForgotPasswordEmail=findViewById(R.id.etForgotPasswordEmail)
        btnNext=findViewById(R.id.btnNext)
        btnNext.setOnClickListener {
            var txt1=etForgotPasswordMobileNumber.text.toString()
            var txt2=etForgotPasswordEmail.text.toString()
            if(txt1!="" && txt2!="")
            {
                println("$txt1 inside")
                println(txt2)
            intent= Intent(this,
                ForgotPasswordBlankActivity::class.java)
            intent.putExtra("ForgotPasswordMobileNumber",etForgotPasswordMobileNumber.text.toString())
            intent.putExtra("ForgotPasswordEmail",etForgotPasswordEmail.text.toString())
            startActivity(intent)
            }
            else
            {
                Toast.makeText(this,"Fill the Above required data with out data unable to process forward",Toast.LENGTH_LONG).show()
            }
        }
    }
}
