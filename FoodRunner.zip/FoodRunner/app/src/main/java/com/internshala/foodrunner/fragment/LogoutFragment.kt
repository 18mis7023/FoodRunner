package com.internshala.foodrunner.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView

import com.internshala.foodrunner.R
import kotlin.system.exitProcess

/**
 * A simple [Fragment] subclass.
 */
class LogoutFragment : Fragment() {

    lateinit var txt1:TextView
    lateinit var txt2:TextView
    lateinit var btnlogout:Button
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view=inflater.inflate(R.layout.fragment_logout, container, false)
        txt1=view.findViewById(R.id.txt1)
        txt2=view.findViewById(R.id.txt2)
        btnlogout=view.findViewById(R.id.btnlogout)
        btnlogout.setOnClickListener {
            System.exit(0)
        }

        txt1.text="KodaliHemanthChowdary4@gmail.com"
        txt2.text="6304360933"


        return view
    }

}
