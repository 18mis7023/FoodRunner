package com.internshala.foodrunner.Activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.internshala.foodrunner.R

class ForgotPasswordBlankActivity : AppCompatActivity() {
    lateinit var txtForgotPasswordMobile: TextView
    lateinit var txtForgotPasswordEmail: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password_blank)
        txtForgotPasswordMobile=findViewById(R.id.txtForgotPasswordMobile)
        txtForgotPasswordEmail=findViewById(R.id.txtForgotPasswordEmail)
        var etxt1:String?
        var etxt2:String?
        if(intent!=null)
        {
            etxt1=intent.getStringExtra("ForgotPasswordMobileNumber")
            etxt2=intent.getStringExtra("ForgotPasswordEmail")
            txtForgotPasswordMobile.text=etxt1
            txtForgotPasswordEmail.text=etxt2
        }
    }
}
