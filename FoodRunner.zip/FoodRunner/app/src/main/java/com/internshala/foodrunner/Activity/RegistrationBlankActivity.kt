package com.internshala.foodrunner.Activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.internshala.foodrunner.R

class RegistrationBlankActivity : AppCompatActivity() {
    lateinit var txtName:TextView
    lateinit var txtEmail:TextView
    lateinit var txtMobile:TextView
    lateinit var txtAddress:TextView
    lateinit var txtPassword:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration_blank)
        if(intent!=null)
        {
            txtName=findViewById(R.id.txtname)
            txtEmail=findViewById(R.id.txtemail)
            txtMobile=findViewById(R.id.txtmobile)
            txtAddress=findViewById(R.id.txtaddress)
            txtPassword=findViewById(R.id.txtpassword)
            var name=intent.getStringExtra("Name")
            var email=intent.getStringExtra("Email")
            var mobile=intent.getStringExtra("MobileNumber")
            var address=intent.getStringExtra("Address")
            var password=intent.getStringExtra("Password")
            txtName.text=name
            txtEmail.text=email
            txtMobile.text=mobile
            txtAddress.text=address
            txtPassword.text=password

            println(password)



        }
    }
}
