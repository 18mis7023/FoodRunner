package com.internshala.foodrunner.Activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.internshala.foodrunner.R

class RegistrationActivity : AppCompatActivity() {
    lateinit var etName:EditText
    lateinit var etEmail:EditText
    lateinit var etMobile:EditText
    lateinit var etAddress:EditText
    lateinit var etRegisterPassword:EditText
    lateinit var etRegisterConfirmPassword:EditText
    lateinit var btnRegister:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       setContentView(R.layout.activity_registration)
        etName=findViewById(R.id.etName)
        etEmail=findViewById(R.id.etEmail)
        etMobile=findViewById(R.id.etMobile)
        etAddress=findViewById(R.id.etAddress)
        etRegisterPassword=findViewById(R.id.etRegisterPassword)
        etRegisterConfirmPassword=findViewById(R.id.etRegisterConfirmPassword)
        btnRegister=findViewById(R.id.btnRegister)
        title="Register Yourself"
        btnRegister.setOnClickListener {
            var intent=Intent(this,
                RegistrationBlankActivity::class.java)
            var registerdpassword=etRegisterPassword.text.toString()
            var confirmPassword=etRegisterConfirmPassword.text.toString()
            if(registerdpassword==confirmPassword)
            {
                intent.putExtra("Name",(etName.text.toString()))
                intent.putExtra("Email",(etEmail.text.toString()))
                intent.putExtra("MobileNumber",(etMobile.text.toString()))
                intent.putExtra("Address",(etAddress.text.toString()))
                intent.putExtra("Password",(etRegisterPassword.text.toString()))
                startActivity(intent)
            }
            else
            {
                Toast.makeText(this,"you entered password and confirm password is not equal",Toast.LENGTH_LONG).show()
            }
        }


    }
}
