package com.internshala.foodrunner.Activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.internshala.foodrunner.R
import com.internshala.foodrunner.fragment.LogoutFragment

class LoginActivity : AppCompatActivity() {
    lateinit var etMobileNumber:EditText
    lateinit var etPassword:EditText
    lateinit var btnLogin:Button
    lateinit var txtForgotPassword:TextView
    lateinit var txtRegister:TextView
    val validateMobile="9491610369"
    val validatePassword="P@ssw0rd"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        etMobileNumber=findViewById(R.id.etMobileNumber)
        etPassword=findViewById(R.id.etPassword)
        btnLogin=findViewById(R.id.btnLogin)
        txtForgotPassword=findViewById(R.id.txtForgotPassword)
        txtRegister=findViewById(R.id.txtRegister)
        var mobilenumber:String
        var password:String

        val intent=Intent(this, LoginBlankActivity::class.java)
        btnLogin.setOnClickListener {
            password=etPassword.text.toString()
            mobilenumber=etMobileNumber.text.toString()
            if(validateMobile==mobilenumber && validatePassword==password)
            {
                intent.putExtra("mobileNumber",mobilenumber)
                intent.putExtra("password",password)
                Toast.makeText(this,"Successfully logined to the page",Toast.LENGTH_LONG).show()
                startActivity(intent)

            }
            else
            {
                Toast.makeText(this,"Mobile Number Or Password is Wrong Please Verify Once",Toast.LENGTH_LONG).show()

            }
        }
        txtRegister.setOnClickListener {
            var intent1=Intent(this,
                RegistrationActivity::class.java)
            startActivity(intent1)
        }
        txtForgotPassword.setOnClickListener {
            var intent2=Intent(this,
                ForgotPasswordActivity::class.java)
            startActivity(intent2)
        }

    }
}
