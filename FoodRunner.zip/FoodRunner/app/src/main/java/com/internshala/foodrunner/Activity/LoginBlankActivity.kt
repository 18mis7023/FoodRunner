package com.internshala.foodrunner.Activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toolbar
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import com.internshala.foodrunner.R
import com.internshala.foodrunner.fragment.*
import kotlinx.android.synthetic.main.activity_login_blank.*

class LoginBlankActivity : AppCompatActivity() {
    lateinit var drawerLayout: DrawerLayout
    lateinit var coordinatorLayout: CoordinatorLayout
    lateinit var frameLayout: FrameLayout
    lateinit var navigationView: NavigationView
    lateinit var toolbar:androidx.appcompat.widget.Toolbar

    /*lateinit var txt1:TextView
    lateinit var txt2:TextView*/
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var previousMenuItem: MenuItem? = null
        setContentView(R.layout.activity_login_blank)
        drawerLayout = findViewById(R.id.drawerlayout)
        coordinatorLayout = findViewById(R.id.coordinatorLayout)
        frameLayout = findViewById(R.id.frame)
        navigationView = findViewById(R.id.navigationview)
        toolbar=findViewById(R.id.toolbar)
        SetUpToolbar()
        val actionBarDrawerToggle = ActionBarDrawerToggle(
            this@LoginBlankActivity,
            drawerLayout,
            R.string.open_drawer,
            R.string.close_drawer
        )
        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()
        openHomeFragment()
            navigationView.setNavigationItemSelectedListener {
            if (previousMenuItem != null) {
                previousMenuItem?.isChecked = false
            }
            it.isCheckable = true
            it.isChecked = true
            previousMenuItem = it
            when (it.itemId) {
                R.id.home -> {
                    supportFragmentManager.beginTransaction().replace(
                        R.id.frame,
                        HomeFragment()
                    ).commit()
                   drawerLayout.closeDrawers()
                    supportActionBar?.title = "Home"
                }
                R.id.Favorite -> {
                    supportFragmentManager.beginTransaction().replace(
                        R.id.frame,
                        FavoriteFragment()
                    ).commit()
                    drawerLayout.closeDrawers()
                    supportActionBar?.title = "Favorite"
                }
                R.id.profile -> {
                    supportFragmentManager.beginTransaction().replace(
                        R.id.frame,
                        MyProfileFragment()
                    ).commit()
                    drawerLayout.closeDrawers()
                    supportActionBar?.title = "My Profile"
                }
                R.id.FAQ -> {
                    supportFragmentManager.beginTransaction().replace(
                        R.id.frame,
                        FaqFragment()
                    ).commit()
                    drawerLayout.closeDrawers()
                    supportActionBar?.title = "Frequently Asked Questions"
                }
                R.id.logout -> {
                    supportFragmentManager.beginTransaction().replace(
                        R.id.frame,
                        LogoutFragment()
                    ).commit()
                    drawerLayout.closeDrawers()
                    supportActionBar?.title = "Logout"
                }
            }
            return@setNavigationItemSelectedListener true
        }
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        var id=item.itemId

        if(id==android.R.id.home)
        {
            drawerlayout.openDrawer(GravityCompat.START)
        }
        return super.onOptionsItemSelected(item)


    }
        fun SetUpToolbar()
        {
            setSupportActionBar(toolbar)
            supportActionBar?.title="Toolbar Title"
            supportActionBar?.setHomeButtonEnabled(true)
            supportActionBar?.setDisplayHomeAsUpEnabled(true)


        }

        fun openHomeFragment() {
            val fragment = HomeFragment()
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(
                R.id.frame,
                HomeFragment()
            )
            transaction.commit()
            supportActionBar?.title = "Home"
            navigationView.setCheckedItem(R.id.home)
            drawerlayout.closeDrawers()

        }

        override fun onBackPressed() {
            val frag = supportFragmentManager.findFragmentById(R.id.frame)

            when (frag) {
                !is HomeFragment -> openHomeFragment()
                else -> super.onBackPressed()
            }
            /* txt1=findViewById(R.id.txt1)
        txt2=findViewById(R.id.txt2)*/
            /* var etxt1:String?
        var etxt2:String?
        if(intent!=null)
        {
            etxt1=intent.getStringExtra("mobileNumber")
            etxt2=intent.getStringExtra("password")
            println("mobile number: $etxt1")
            println("Password: $etxt2")
            txt1.text=etxt1
            txt2.text=etxt2
        }*/

        }

    }


